# Acceso DOUR

- Key fija: `123`
- Acceso permanente.
- El proyecto incluye un Cloudflare Worker compatible con `/api/activate` y `/api/patches`.
- El Worker debe desplegarse para tener validación remota real. La app incluye respaldo local para no bloquear el inicio.
