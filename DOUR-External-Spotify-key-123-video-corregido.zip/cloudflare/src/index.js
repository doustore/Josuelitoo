const ACCESS_KEY = "123";
const json = (body, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store",
    "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, GET, OPTIONS" }
});
async function handle(request) {
  const url = new URL(request.url);
  if (request.method === "OPTIONS") return new Response(null, {status:204, headers:{
    "Access-Control-Allow-Origin":"*", "Access-Control-Allow-Headers":"Content-Type",
    "Access-Control-Allow-Methods":"POST, GET, OPTIONS"}});
  if (url.pathname === "/" || url.pathname === "/health")
    return json({ok:true, service:"DOUR fixed-key server"});
  if (request.method !== "POST") return json({error:"not_found"},404);
  let data;
  try { data = await request.json(); } catch { return json({error:"invalid_request"},400); }
  if (url.pathname === "/api/activate") {
    if (data.key !== ACCESS_KEY) return json({error:"invalid_key"},403);
    return json({ok:true, role:"admin", menus:["all"], permanent:true});
  }
  if (url.pathname === "/api/patches") {
    if (data.key !== ACCESS_KEY) return json({error:"invalid_key"},403);
    return json({ok:true, patches:[]});
  }
  return json({error:"not_found"},404);
}
export default { fetch: handle };
