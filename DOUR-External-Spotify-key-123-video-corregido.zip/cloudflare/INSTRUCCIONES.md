# DOUR — servidor de key fija 123

El Worker incluido valida la key `123` de forma permanente en `/api/activate` y `/api/patches`.

## Despliegue
1. Instala Node.js y Wrangler: `npm install -g wrangler`.
2. Entra a Cloudflare: `wrangler login`.
3. Desde esta carpeta ejecuta: `wrangler deploy`.
4. Copia la URL HTTPS que entrega Cloudflare.
5. Para activar la validación remota desde la app, configura `PantherAPIBaseURL` en `ThreeOneOSFive/Info.plist` con esa URL y recompila.

La app también acepta `123` localmente como respaldo, por lo que puede abrir aunque el Worker todavía no esté desplegado. El acceso remoto solo estará disponible después del despliegue y de configurar la URL.

**Seguridad:** `123` es una clave pública y compartida, no sirve para proteger contenido privado ni distinguir usuarios. Cualquier persona que conozca el proyecto puede acceder.
