# Cambios DOUR / External Spotify

- Se sustituyó la pantalla de video inicial por la imagen de inicio de Spotify proporcionada (`SpotifySplash`).
- Se conserva la pantalla DOUR / EXTERNAL SPOTIFY y el valor inicial `123` en el campo Key.
- El botón «Continuar» sigue enviando la key al servidor HTTPS configurado.
- La validación de `123` depende de que esa licencia exista y esté habilitada en el backend. No se agregó un bypass local ni una clave maestra insegura.

**Pendiente del backend:** este ZIP no incluye acceso a la base de datos ni a la configuración del servicio Lovable. Por tanto, el proyecto iOS por sí solo no puede registrar/activar la licencia `123`. El administrador del backend debe crearla/habilitarla para el dispositivo.

No se pudo compilar ni probar el proyecto en Xcode porque este entorno no dispone de macOS/Xcode.
